package com.ex.myBatisBoard.mapper;

import com.ex.myBatisBoard.dto.BoardDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface BoardMapper {
    List<BoardDto> findAll();

    void save(@Param("boardDto") BoardDto dto);

    void updateHits(@Param("id") Long id);

    BoardDto findById(@Param("id") Long id);

    void deleteById(@Param("id") Long id);

    void updateBoard(@Param("boardDto")BoardDto dto);

    List<BoardDto> searchList(@Param("category")String category,
                                @Param("keyword")String keyword);
}
