package com.ex.myBatisBoard.mapper;

import com.ex.myBatisBoard.dto.BoardDto;
import com.ex.myBatisBoard.dto.BoardFileDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Mapper
public interface BoardMapper {
    List<BoardDto> findAll();

    void save(@Param("boardDto") BoardDto dto);

    void updateHits(@Param("id") Long id);

    BoardDto findById(@Param("id") Long id);

    void deleteById(@Param("id") Long id);

    void updateBoard(@Param("boardDto")BoardDto dto);

    List<BoardDto> searchList(@Param("category")String category,
                                @Param("keyword")String keyword);

    void saveFile(@Param("boardFileDto") BoardFileDto boardFileDto);

    List<BoardFileDto> findFile(@Param("id")Long id);
}
