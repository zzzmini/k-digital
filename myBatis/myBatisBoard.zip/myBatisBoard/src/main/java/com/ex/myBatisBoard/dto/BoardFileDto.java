package com.ex.myBatisBoard.dto;

import lombok.Data;

@Data
public class BoardFileDto {
    private Long id;
    private Long boardId;
    private String originalFileName;
    private String storedFileName;
}
