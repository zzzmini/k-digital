package com.ex.myBatisBoard.controller;

import com.ex.myBatisBoard.dto.BoardDto;
import com.ex.myBatisBoard.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class BoardController {
    @Autowired
    BoardService boardService;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/save")
    public String save() {
        return "save";
    }

    @GetMapping("/list")
    public String findAllList(Model model) {
        List<BoardDto> boardDtoList = boardService.findAll();
        model.addAttribute("lists",boardDtoList);
        return "list";
    }
}
