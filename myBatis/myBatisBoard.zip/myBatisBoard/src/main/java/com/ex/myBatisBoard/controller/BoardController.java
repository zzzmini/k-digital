package com.ex.myBatisBoard.controller;

import com.ex.myBatisBoard.dto.BoardDto;
import com.ex.myBatisBoard.dto.BoardFileDto;
import com.ex.myBatisBoard.service.BoardService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.util.List;

@Controller
public class BoardController {
    @Autowired
    BoardService boardService;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/save")
    public String save() {
        return "save";
    }

    @GetMapping("/list")
    public String findAllList(Model model) {
        List<BoardDto> boardDtoList = boardService.findAll();
        model.addAttribute("lists", boardDtoList);
        return "list";
    }

    @PostMapping("/save")
    public String saveBoard(BoardDto dto) throws IOException {
        System.out.println(dto);
        boardService.save(dto);
        return "redirect:/list";
    }

    @GetMapping("/detail/{id}")
    public String showDetail(@PathVariable("id") Long id, Model model) {
        // 조회수 업데이트
        boardService.updateHits(id);

        // 상세내용을 다시 가져옴.
        BoardDto dto = boardService.findById(id);
        model.addAttribute("dto", dto);
        System.out.println(dto);

        if (dto.getFileAttached() == 1) {
            List<BoardFileDto> boardFiles = boardService.findFile(id);
            System.out.println("====  boardFiles : " + boardFiles);
            model.addAttribute("boardFiles", boardFiles);
        }

        return "detail";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") Long id) {
        boardService.deleteById(id);
        return "redirect:/list";
    }

    @GetMapping("/update/{id}")
    public String update(@PathVariable("id") Long id, Model model) {

        BoardDto dto = boardService.findById(id);
        model.addAttribute("dto", dto);
        return "update";
    }

    @PostMapping("/update/{id}")
    public String update(@PathVariable("id") Long id,
                         BoardDto dto) {
        System.out.println(dto);
        boardService.updateBoard(dto);
        return "redirect:/list";
    }

    @GetMapping("/search")
    public String search(@RequestParam("search")String category,
                         @RequestParam("keyword")String keyword,
                         Model model) {
        List<BoardDto> boardDtoList = boardService.searchList(category, keyword);
        model.addAttribute("lists", boardDtoList);
        return "/list";
    }
}
