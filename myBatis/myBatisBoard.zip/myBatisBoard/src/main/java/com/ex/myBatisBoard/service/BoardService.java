package com.ex.myBatisBoard.service;

import com.ex.myBatisBoard.dto.BoardDto;
import com.ex.myBatisBoard.mapper.BoardMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BoardService {
    private final BoardMapper boardMapper;

    public List<BoardDto> findAll() {
        return boardMapper.findAll();
    }
}
