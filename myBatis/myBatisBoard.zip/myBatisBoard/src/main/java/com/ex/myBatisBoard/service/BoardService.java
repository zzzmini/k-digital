package com.ex.myBatisBoard.service;

import com.ex.myBatisBoard.dto.BoardDto;
import com.ex.myBatisBoard.dto.BoardFileDto;
import com.ex.myBatisBoard.mapper.BoardMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BoardService {
    private final BoardMapper boardMapper;

    public List<BoardDto> findAll() {
        return boardMapper.findAll();
    }

    public void save(BoardDto dto) throws IOException {
        if (dto.getBoardFile().get(0).isEmpty()) {
            // 파일 없다.
            dto.setFileAttached(0);
            boardMapper.save(dto);
//            System.out.println(dto);
        } else {
            // 파일 있다.
            dto.setFileAttached(1);
            // 게시글 저장 후 id 값을 활용하기 위해 id를 리턴 받음.
            boardMapper.save(dto);  // 추가 수정(매퍼부분과 xml을 수정)
            System.out.println("===============" + dto);
            BoardDto savedBoard = boardMapper.findById(dto.getId());

            // 파일만 따로 가져오기
            for (MultipartFile boardFile : dto.getBoardFile()) {
                String originalFileName = boardFile.getOriginalFilename();
                // 저장용 파일이름
                String storedFileName = System.currentTimeMillis() + "-" + originalFileName;

                // BoardFileDto 셋팅
                BoardFileDto fileDto = new BoardFileDto();
                fileDto.setOriginalFileName(originalFileName);
                fileDto.setStoredFileName(storedFileName);
                fileDto.setBoardId(savedBoard.getId());

                // 파일 저장용 폴더에 파일들을 저장
                String savePath = "C:/upload_files/" + storedFileName;
                boardFile.transferTo(new File(savePath));

                // board_file_table 에 저장 처리
                boardMapper.saveFile(fileDto);
            }
        }
    }

    public void updateHits(Long id) {
        boardMapper.updateHits(id);
    }

    public BoardDto findById(Long id) {
        return boardMapper.findById(id);
    }

    public void deleteById(Long id) {
        boardMapper.deleteById(id);
    }

    public void updateBoard(BoardDto dto) {
        boardMapper.updateBoard(dto);
    }

    public List<BoardDto> searchList(String category, String keyword) {
        return boardMapper.searchList(category, keyword);
    }

    public List<BoardFileDto> findFile(Long id) {
        return boardMapper.findFile(id);
    }
}
