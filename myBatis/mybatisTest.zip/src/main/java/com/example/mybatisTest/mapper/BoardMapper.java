package com.example.mybatisTest.mapper;

import com.example.mybatisTest.dto.BoardDTO;
import com.example.mybatisTest.dto.BoardFileDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface BoardMapper {
    void save(@Param("boardDto") BoardDTO boardDTO);

    List<BoardDTO> findAll();

    void updateHit(@Param("id") Long id);

    BoardDTO findById(@Param("id") Long id);

    void deleteById(@Param("id") Long id);

    void update(@Param("boardDto") BoardDTO boardDTO);

    void saveFile(@Param("boardFile")BoardFileDTO boardFileDTO);

    List<BoardFileDTO> findFile(@Param("id") Long id);
}
