package com.example.mybatisTest.controller;

import com.example.mybatisTest.dto.BoardDTO;
import com.example.mybatisTest.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class BoardController {
    @Autowired
    BoardService boardService;

    @GetMapping("/")
//    @RequestMapping(value = {"/",""}, method = RequestMethod.GET)
    public String index(){
        return "index";
    }

    @GetMapping("/save")
    public String save(){
        return "save";
    }

    @PostMapping("/save")
    public String saveBoard(BoardDTO boardDTO){
        System.out.println("boardDTO : " + boardDTO.toString());
        boardService.save(boardDTO);
        return "redirect:/list";
    }

    @GetMapping("/list")
    public String findAll(Model model) {
        List<BoardDTO> boardDTOList = boardService.findAll();
        model.addAttribute("boardList", boardDTOList);
        return "list";
    }

    @GetMapping("/{id}")
    public String findById(@PathVariable("id") Long id, Model model) {
        // 조회수 처리
        boardService.updateHits(id);
        // 상세내용 가져옴
        BoardDTO boardDTO = boardService.findById(id);
        model.addAttribute("board", boardDTO);
        return "detail";
    }
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id")Long id){
        boardService.delete(id);
        return "redirect:/list";
    }
}
