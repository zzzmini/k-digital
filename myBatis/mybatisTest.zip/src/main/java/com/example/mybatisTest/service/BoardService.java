package com.example.mybatisTest.service;

import com.example.mybatisTest.dto.BoardDTO;
import com.example.mybatisTest.mapper.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
public class BoardService {
    @Autowired
    BoardMapper boardMapper;

    public void save(BoardDTO boardDTO){
        boardMapper.save(boardDTO);
    }

    public List<BoardDTO> findAll() {
        return boardMapper.findAll();
    }

    public void updateHits(Long id) {
        boardMapper.updateHit(id);
    }

    public BoardDTO findById(Long id) {
        return boardMapper.findById(id);
    }

    public void delete(Long id) {
        boardMapper.deleteById(id);
    }
}
