package com.my.firstApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.my.firstApp.dto.AdminDto;
import com.my.firstApp.service.AdminService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	AdminService adminService;

	@GetMapping("")
	public String mainView() {
		return "main";
	}
	
	@GetMapping("/loginForm")
	public String loginFormView() {
		return "login_form";
	}
	
	@GetMapping("/createAccountForm")
	public String createAccountForm() {
		return "create_account_form";
	}
	
	@PostMapping("/createAccountConfirm")
	public String insertAdminAccount(AdminDto adminDto) {
		System.out.println(adminDto);
		adminService.adminInsert(adminDto);
		return "create_account_form";
	}
}







