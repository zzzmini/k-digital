package com.my.firstApp.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.my.firstApp.dto.AdminDto;

@Mapper
public interface AdminMapper {

	void adminInsert(@Param("adminDto")AdminDto adminDto);

}
