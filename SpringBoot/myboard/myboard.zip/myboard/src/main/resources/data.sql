insert into article(title, content) values ('가가가가', '1111');
insert into article(title, content) values ('나나나나', '2222');
insert into article(title, content) values ('다다다다', '3333');

insert into article(title, content) values ('당신의 인생 영화는?', '댓글 고');
insert into article(title, content) values ('당신의 소울 푸드는?', '댓글 고고');
insert into article(title, content) values ('당신의 취미는?', '댓글 고고고');