$(document).ready(function(){
    $(document).on("click", "#comment-delete-btn", function(){
        let deleteCommentId = $(this).next().val();
        $.ajax({
            url : '/api/comments/' + deleteCommentId,
            type : 'DELETE',
            async : true,
            headers : {
                'Content-Type' : 'application/json',
            },
            dataType : 'text',
            success : ()=> {
                alert('댓글이 정상적으로 삭제됐습니다.');
                window.location.reload();
                },
                error : function(request, status, error){
                    alert('댓글 삭제에 실패했습니다. 관리자에게 문의하세요.');
                }
        });
    });

    $("#comment-create-btn").on("click", function(){
        const comment = {
            nickname : $("#new-comment-nickname").val(),
            body : $("#new-comment-body").val(),
            articleId : $("#new-comment-article-id").val()
        }
        let sendUrl = '/api/articles/' + comment.articleId + '/comments';
        $.ajax({
            type : 'POST',
            url : sendUrl,
            async : true,
            headers : {
                'Content-Type' : 'application/json',
            },
            dataType : 'json',
            data : JSON.stringify(comment),
            success : ()=> {
                alert('댓글이 등록됐습니다.');
                window.location.reload();
            },
            error : function(request, status, error){
                alert('댓글 등록에 실패했습니다. 관리자에게 문의하세요.');
            }
        })
    });

    $("#comment-update-btn").on("click", function(){
        const comment = {
                    nickname : $("#update-comment-nickname").val(),
                    body : $("#update-comment-body").val(),
                    commentId : $("#comment_id").val(),
                    articleId : $("#article_id").val()
                }
                console.log(comment);
                let sendUrl = '/api/comments/' + comment.commentId;
        $.ajax({
                    type : 'PATCH',
                    url : sendUrl,
                    async : true,
                    headers : {
                        'Content-Type' : 'application/json',
                    },
                    dataType : 'json',
                    data : JSON.stringify(comment),
                    success : (res)=> {

                        alert('댓글이 수정됐습니다.');
                        window.location.href='/articles/' + comment.articleId;
                    },
                    error : function(request, status, error){
                        alert('댓글 수정에 실패했습니다. 관리자에게 문의하세요.');
                    }
                })
                console.log(arr);
    });
});
