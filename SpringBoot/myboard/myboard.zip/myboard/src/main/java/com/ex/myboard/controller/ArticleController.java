package com.ex.myboard.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ArticleController {
    @GetMapping("/articles")
    public String showAllArticles() {
        return "show_all";
    }
}
