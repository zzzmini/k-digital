package com.ex.myboard.controller;

import com.ex.myboard.dto.CommentDto;
import com.ex.myboard.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class CommentController {
    @Autowired
    ArticleService articleService;

    @GetMapping("/articleComment/{id}/update")
    public String commentUpdateFormView(@PathVariable("id")Long commentId,
                                        Model model) {
        CommentDto commentDto = articleService.getOneComment(commentId);
        model.addAttribute("commentDto", commentDto);
        return "update_comment";
    }
}
