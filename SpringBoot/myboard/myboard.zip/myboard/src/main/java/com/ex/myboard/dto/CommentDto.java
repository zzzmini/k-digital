package com.ex.myboard.dto;

import lombok.Data;

@Data
public class CommentDto {
    private Long commentId;
    private Long articleId;
    private String nickname;
    private String body;
}
