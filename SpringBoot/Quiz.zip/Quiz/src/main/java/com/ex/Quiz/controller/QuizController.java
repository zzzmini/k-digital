package com.ex.Quiz.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class QuizController {
    @GetMapping("/")
    public String mainList(){
        return "quizList";
    }
    @GetMapping("/quiz/insert")
    public String quizInsert(){
        return "quizForm";
    }
}
