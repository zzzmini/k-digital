package com.ex.myboard.api;

import com.ex.myboard.dto.CommentDto;
import com.ex.myboard.entity.Comment;
import com.ex.myboard.service.ApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CommentApiController {
    @Autowired
    ApiService apiService;
    // 1. 특정 게시글의 댓글을 조회
    @GetMapping("/api/articles/{articleId}/comments")
    public ResponseEntity<List<CommentDto>> getComments
                        (@PathVariable("articleId") Long id) {
        List<CommentDto> comments = apiService.getComments(id);
        return ResponseEntity.status(HttpStatus.OK).body(comments);
    }

    // 2. 댓글 생성
    @PostMapping("/api/articles/{articleId}/comments")
    public ResponseEntity<CommentDto> createComment(
            @PathVariable("articleId") Long articleId, @RequestBody CommentDto dto) {
        apiService.createComment(articleId, dto);
        return ResponseEntity.status(HttpStatus.OK).body(dto);
    }

    // 3. 댓글 삭제
    @DeleteMapping("/api/comments/{commentId}")
    public ResponseEntity<CommentDto> deleteComment(
            @PathVariable("commentId")Long commentId) {
        apiService.deleteComment(commentId);
        return null;
    }

    // 4. 댓글 수정
    @PatchMapping("/api/comments/{commentId}")
    public void updateComment(
            @PathVariable("commentId")Long commentId,
            @RequestBody CommentDto dto) {
            apiService.updateComment(commentId, dto);
    }
}