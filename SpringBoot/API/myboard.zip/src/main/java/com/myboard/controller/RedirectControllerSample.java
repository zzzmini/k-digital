package com.myboard.controller;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.io.IOException;

@Controller
@RequestMapping("redirect/sample")
public class RedirectControllerSample {
    String URL = "page";
    String REDIRECT_URL = "redirect:" + URL;

    @GetMapping("page")
    public String view(){
        return "/test/page";
    }

    @RequestMapping(value = "test1", method = RequestMethod.GET)
    public String test1(Model model) {
        model.addAttribute("msg", REDIRECT_URL);
        return REDIRECT_URL;
    }

    @GetMapping("/test2")
    public ModelAndView test(Model model) {
        model.addAttribute("msg", REDIRECT_URL);
        return new ModelAndView(REDIRECT_URL);
    }

    @RequestMapping(value = "/test3", method = RequestMethod.GET)
    public void test3(HttpServletResponse httpServletResponse, Model model) throws IOException {
        model.addAttribute("msg", REDIRECT_URL);
        httpServletResponse.sendRedirect(URL);
    }

    @GetMapping("test4")
    public RedirectView test4(Model model, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("msg", "Test4 : " + REDIRECT_URL);
        model.addAttribute("msg", REDIRECT_URL);
        RedirectView redirectView = new RedirectView();
        redirectView.setUrl(URL);
        return redirectView;
    }

    @GetMapping("test5")
    public String test5(Model model) {
        model.addAttribute("msg", "Test5 : " + REDIRECT_URL);
        URL = "test/page";
        return URL;
    }
}
