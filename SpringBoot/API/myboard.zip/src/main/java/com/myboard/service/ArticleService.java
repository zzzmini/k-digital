package com.myboard.service;

import com.myboard.dto.ArticleForm;
import com.myboard.entity.Article;
import com.myboard.repository.ArticleRepository;
import groovy.util.logging.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArticleService {
    private final ArticleRepository articleRepository;

    public ArticleService(ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    public List<Article> showAllList() {
        return articleRepository.findAll();
    }

    public Article showOneList(Long id) {
        return articleRepository.findById(id).orElse(null);
    }

    public Article createArticle(ArticleForm dto) {
        Article article = dto.toEntity();
        return articleRepository.save(article);
    }

    public ResponseEntity<Article> patchUpdate(Long id, ArticleForm dto) {
        //1. DTO -> 엔티티 변환하기
        Article article = dto.toEntity();
        //2. 타깃 조회하기
        Article target = articleRepository.findById(id).orElse(null);

        //3. 잘못된 요청 처리하기
        if (target == null || target.getId() != id) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        //4. 업데이트 및 정상 응답(200) 하기
        // 수정하기
        Article updated = articleRepository.save(article);
        return ResponseEntity.status(HttpStatus.OK).body(updated);
    }

    public ResponseEntity<Article> delete(Long id) {
        //1. 대상찾기
        Article target = articleRepository.findById(id).orElse(null);

        //2. 잘못된 요청 처리하기
        if (target == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        //3. 대상 삭제하기
        articleRepository.delete(target);

        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
