package com.myboard.service;

import com.myboard.dto.ArticleForm;
import com.myboard.entity.Article;
import com.myboard.repository.ArticleRepository;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestPropertySource(locations="classpath:application-test.properties")
@Transactional
class ArticleServiceTest {
    @Autowired
    ArticleService articleService;

    @Autowired
    ArticleRepository articleRepository;

    public void createArticleList(){
        for (int i=1; i<=5; i++) {
            ArticleForm article = new ArticleForm();
            article.setTitle("제목" + i);
            article.setContent("내용" + i);
            articleService.createArticle(article);
        }
    }

    @Test
    void 전체_데이터_조회() {
        //1. 예상데이터
        //Given
        this.createArticleList();

        //2. 실제데이터
        Article a1 = new Article(null, "제목1", "내용1");
        Article a2 = new Article(null, "제목2", "내용2");
        Article a3 = new Article(null, "제목3", "내용3");
        Article a4 = new Article(null, "제목4", "내용4");
        Article a5 = new Article(null, "제목5", "내용5");
        List<Article> expected = new ArrayList<>(Arrays.asList(a1, a2, a3, a4, a5));

        //When
        List<Article> articleList = articleService.showAllList();
        //3. 비교 및 검증
        //Then
        assertEquals(expected.stream().count(), articleList.stream().count());  // JUnit5
        assertThat(articleList.stream().count()).isEqualTo(5);   // Assertj
    }

    @Test
    void 단건_조회_성공() {

        //Given
        this.createArticleList();
        Long id = 1L;
        Article expected = new Article(id, "제목1", "내용1");
        //When
        Article article = articleService.showOneList(id);
        //Then
        assertEquals(expected.toString(), article.toString());
    }

    @Test
    @Transactional
    void 단건_조회_실패() {
        //Given
        this.createArticleList();
        Long id = -1L;
        Article expected = null;
        //When
        Article article = articleService.showOneList(id);
        //Then
        assertEquals(expected, article);
    }

    @Test
    void 게시글_입력() {
        //Given
        Article expected = new Article(null, "제목6", "내용6");
        Article input = new Article(null, "제목6", "내용6");
        //When
        Article searchData = articleService.createArticle(ArticleForm.to(input));

        //Then
        assertEquals(expected.getTitle(), searchData.getTitle());
        assertEquals(expected.getContent(), searchData.getContent());
    }

    @Test
    void patchUpdate() {
        //Given
        //When
        //Then
    }

    @Test
    void delete() {
        //Given
        //When
        //Then
    }
}